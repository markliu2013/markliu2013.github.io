<?php
	$vegetables = $_GET['vegetables'];
	$fruit = $_GET['fruit'];
	$nuts = $_GET['nuts'];
	$bacon = $_GET['bacon'];
	echo 'vegetables:' .$vegetables. ',fruit:' .$fruit. ',nuts:' .$nuts. ',bacon:' .$bacon;
 ?>